`estimateNugget` <-
function(X,Y) {
	return (mean(varPerReps(X,Y)))
}

