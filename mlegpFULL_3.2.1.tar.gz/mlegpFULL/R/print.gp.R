`print.gp` <-
function(x, ...) {
	summary(x)
}

