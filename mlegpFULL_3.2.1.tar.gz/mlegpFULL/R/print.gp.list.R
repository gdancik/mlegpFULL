`print.gp.list` <-
function(x, nums = NULL, ...) {
	summary(x, nums = nums)
}

