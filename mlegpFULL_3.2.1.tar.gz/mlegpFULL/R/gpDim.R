`gpDim` <-
function(gp) {
	return (gp$numDim)
}

