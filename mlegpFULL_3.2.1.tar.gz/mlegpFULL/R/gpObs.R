`gpObs` <-
function(gp) {
	return (gp$numObs)
}

